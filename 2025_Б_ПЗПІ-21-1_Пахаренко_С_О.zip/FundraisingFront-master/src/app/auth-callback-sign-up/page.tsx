"use client"

import { authenticateWithBackendSignUp } from "@/app/actions/auth"
import { Button } from "@/components/ui/button"
import { useEffect, useTransition } from "react"

export default function AuthCallbackSignUpPage() {
  const [isPending, startTransition] = useTransition()

  useEffect(() => {
    const timer = setTimeout(() => {
      startTransition(async () => {
        await authenticateWithBackendSignUp()
      })
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center space-y-4">
        <h1 className="text-2xl font-bold">{isPending ? "Authenticating..." : "Complete Authentication"}</h1>
        <p className="text-gray-600">
          {isPending
            ? "Please wait while we authenticate you."
            : "Click the button below to complete your authentication."}
        </p>

        <Button
          onClick={() =>
            startTransition(async () => {
              await authenticateWithBackendSignUp()
            })
          }
          disabled={isPending}
        >
          {isPending ? "Authenticating..." : "Complete Authentication"}
        </Button>

        {isPending && <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>}
      </div>
    </div>
  )
}
