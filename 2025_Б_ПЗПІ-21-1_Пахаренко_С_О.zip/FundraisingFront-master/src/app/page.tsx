"use client";

import { CardList } from "@/components/card-base";
import { Footer } from "@/components/footer";
import { Header } from "@/components/header";
import { ImageSlider } from "@/components/image-slider";
import { InputSearch } from "@/components/input-search";
import { Sidebar } from "@/components/sidebar";
import { startTransition, useEffect, useState } from "react";
import { getInitiativeByCategories } from "./actions/initiatives";
import { Loader } from "@/components/loader";
import { Category, getAllCategories } from "./actions/categories";
import { Pagination } from "@/components/pagination";
import { isAuth } from "./actions/auth";


export default function Home() {
  const [initiatives, setInitiatives] = useState([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [token, setToken] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  const isLoading = loading;
  const isEmpty = !loading && initiatives.length === 0;

  const loadInitiatives = async (page: number, categoryNames: string[]) => {
    setCurrentPage(page);
    setSelectedCategories(categoryNames);
    setLoading(true);
    try {
      const data = await getInitiativeByCategories(page, categoryNames);
      setInitiatives(data.items);
      setTotalPages(Math.ceil(data.totalCount / data.pageSize));
    } catch (error) {
      console.error("Error loading initiatives:", error);
      setInitiatives([]);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyFilter = (categories: string[]) => {
    loadInitiatives(1, categories);
  };

  useEffect(() => {
    startTransition(async () => {
      const categoriesResponse = await getAllCategories();
      const token = await isAuth();
      setCategories(categoriesResponse);
      setToken(token);
      loadInitiatives(1, []);
    });
  }, []);


  const filteredInitiatives = initiatives.filter((initiative: any) => {
    const query = searchQuery.toLowerCase();
    return (
      initiative.title?.toLowerCase().includes(query) ||
      initiative.description?.toLowerCase().includes(query)
    );
  });

  const handlePageChange = (page: number) => {
    loadInitiatives(page, selectedCategories);
  };


  return (
    <section className="" id="home">
      <Header token={token} />
      <ImageSlider />
      <div className="flex gap-4">
        <div className="w-[30%] bg-white p-4 rounded">
          <Sidebar
            categories={categories}
            onApplyFilter={handleApplyFilter}
            selectedCategories={selectedCategories}
          />
        </div>
        <div className="w-[70%] bg-white p-4 rounded">
          <InputSearch
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
          <div className="mt-4">
            {isLoading ? (
              <Loader />
            ) : isEmpty ? (
              <div className="text-center text-gray-500 mt-10">
                Ініціатив не знайдено.              </div>
            ) : (
              <CardList initiatives={filteredInitiatives} />
            )}
          </div>
          <div className="mt-6 flex justify-center">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />
          </div>
        </div>
      </div>
      <Footer />
    </section>
  );
}
