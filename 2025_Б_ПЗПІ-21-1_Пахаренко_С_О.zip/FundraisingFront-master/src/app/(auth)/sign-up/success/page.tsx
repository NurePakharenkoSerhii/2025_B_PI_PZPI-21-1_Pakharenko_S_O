import Link from "next/link"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Success() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center space-y-8">
        {/* Success Circle with Chevron */}
        <div className="flex justify-center">
          <div className="w-24 h-24 bg-transparent border-2 border-black rounded-full flex items-center justify-center shadow-lg">
            <Check className="w-8 h-8 text-black" />
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-gray-900">Ви успішно зареєструвалися</h1>
          <p className="text-gray-600 max-w-md mx-auto">
            Ваш акаунт було створено успішно. Тепер ви можете увійти в систему.
          </p>
        </div>

        <div>
          <Button asChild className="px-8 py-3">
            <Link href="/sign-in">Увійти в систему</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
