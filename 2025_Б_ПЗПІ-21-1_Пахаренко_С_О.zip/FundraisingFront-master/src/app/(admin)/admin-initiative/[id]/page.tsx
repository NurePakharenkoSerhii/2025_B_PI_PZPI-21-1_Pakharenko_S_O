"use client"
import { getAllCategories } from "@/app/actions/categories";
import { approveInitiative, changeInitiativeCategory, deleteInitiative, getInitiativeById } from "@/app/actions/initiatives";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, CheckCircle, Share2 } from "lucide-react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { startTransition, useEffect, useState } from "react";
import { toast } from "sonner";


export type Initiative = {
  id: number;
  title: string;
  description: string;
  imageBase64: string;
  isApproved: boolean;
};
export type Category = {
  id: number
  categoryName: string
}

export default function AdminInitiativePage() {
  const params = useParams()
  const router = useRouter()
  const id = Number(params.id)
  const [initiative, setInitiative] = useState<Initiative>()
  const [category, setCategory] = useState("")
  const [categories, setCategories] = useState<Category[]>([])


  useEffect(() => {
    startTransition(async () => {
      const initiativeById = await getInitiativeById(id);
      const allCategories = await getAllCategories();

      setInitiative(initiativeById);
      setCategories(allCategories);

      const matchedCategory = allCategories.find(
        (cat) => cat.id === initiativeById.categoryId
      );
      if (matchedCategory) {
        setCategory(matchedCategory.categoryName);
      }
    });
  }, [id]);


  const handleFinishEdit = async () => {
    const selectedCategory = categories.find((cat) => cat.categoryName === category);

    if (!selectedCategory || !initiative) {
      toast.error("Категорія або ініціатива відсутня");
      return;
    }

    const success = await changeInitiativeCategory(initiative.id, selectedCategory.id);

    if (success) {
      toast.success("Категорію оновлено успішно");

      const allCategories = await getAllCategories();
      setCategories(allCategories);

      const updatedCategory = allCategories.find(cat => cat.id === selectedCategory.id);
      if (updatedCategory) {
        setCategory(updatedCategory.categoryName);
      }
    } else {
      toast.error("Не вдалося оновити категорію");
    }
  };

  const handleApproveInitiative = async () => {
    if (!initiative) {
      toast.error("Ініціатива не знайдена");
      return;
    }

    const success = await approveInitiative(initiative.id, true);

    if (success) {
      toast.success("Ініціатива підтверджена успішно");
      setInitiative({ ...initiative, isApproved: true });
    } else {
      toast.error("Не вдалося підтвердити ініціативу");
    }
  };

  const handleDeleteInitiative = async () => {
  if (!initiative) {
    toast.error("Ініціатива не знайдена");
    return;
  }

  const result = await deleteInitiative(initiative.id);

  if (result) {
    toast.success("Ініціатива успішно видалена");
    router.push("/admin");
  } else {
    toast.error("Не вдалося видалити ініціативу");
  }
};


  return (
    <div className="py-8 px-4">
      <Link href="/admin" className="flex items-center text-gray-600 hover:text-gray-900 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Назад до списку ініціатив
      </Link>

      <div className="bg-white rounded-lg shadow-md overflow-hidden max-w-4xl mx-auto">
        <div className="relative w-full h-[300px] sm:h-[400px]">
          <img
            src={`data:image/jpeg;base64,${initiative?.imageBase64}` || "/placeholder.svg"}
            alt={initiative?.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">{initiative?.title}</h1>
          <p className="text-gray-600 mb-6">{initiative?.description}</p>
          <div className="space-y-6">
            <div>
              <h2 className="text-sm font-medium mb-2">Категорія</h2>
              <p className="text-gray-800">{category}</p>
            </div>

            <div>
              <h2 className="text-sm font-medium mb-2">Список доступних категорій</h2>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Оберіть категорію" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.categoryName}>
                      {cat.categoryName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            {initiative?.isApproved ? (
              <div className="flex items-center justify-between gap-4 pt-4 text-green-600 font-medium">
                 <Button className="flex-1 cursor-pointer" onClick={handleFinishEdit}>
                  Завершити редагування
                </Button>
                <Button variant="destructive" className="flex-1 cursor-pointer"  onClick={handleDeleteInitiative}>
                  Видалити ініціантиву
                </Button>

                <CheckCircle className="w-5 h-5" />
                Ініціатива підтверджена
                
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button className="flex-1 cursor-pointer" onClick={handleFinishEdit}>
                  Завершити редагування
                </Button>
                <Button variant="destructive" className="flex-1 cursor-pointer"  onClick={handleDeleteInitiative}>
                  Видалити ініціантиву
                </Button>
                <Button className="flex-1 cursor-pointer bg-emerald-400" onClick={handleApproveInitiative}>
                  Підтвердити ініціантиву
                </Button>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
