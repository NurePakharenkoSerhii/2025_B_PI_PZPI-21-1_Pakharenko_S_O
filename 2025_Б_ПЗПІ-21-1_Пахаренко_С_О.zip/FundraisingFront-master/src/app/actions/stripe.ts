"use server"

import { cookies } from "next/headers"

type StripeSession = {
    fundraisingId:number;
    amount:number;
    successUrl: string;
    cancelUrl: string;
}


/* export async function createCheckoutSession(stripeSession:StripeSession) {
     try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const stripe = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Stripe/create-checkout-session`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
            body:JSON.stringify(stripeSession)
        })

        console.log(stripe , "stripe")
        if (!stripe.ok) {
            throw new Error("Failed to create stripe session")
        }

        const response = await stripe.json()

        return response

    } catch (error) {
        console.error("Error create stripe session:", error)
        return []
    }
} */