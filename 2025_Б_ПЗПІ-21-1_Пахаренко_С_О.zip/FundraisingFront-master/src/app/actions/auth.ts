"use server"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { currentUser } from "@clerk/nextjs/server"
import { z } from "zod"

export type FormState = {
  message: string
  errors: {
    firstName: string[]
    secondName: string[]
    email: string[]
    password: string[]
    confirmPassword: string[]
  }
}

export type SignInFormState = {
  message: string
  errors: {
    email: string[]
    password: string[]
  }
}

const SignUpSchema = z
  .object({
    firstName: z
      .string()
      .min(3, { message: "First name must be at least 3 characters long" })
      .max(50, { message: "First name must be less than 50 characters" })
      .trim(),
    secondName: z
      .string()
      .min(3, { message: "Second name must be at least 3 characters long" })
      .max(50, { message: "Second name must be less than 50 characters" })
      .trim(),
    email: z.string().email({ message: "Please enter a valid email address" }).trim(),
    password: z
      .string()
      .min(8, { message: "Password must be at least 8 characters long" })
      .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" })
      .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter" })
      .regex(/[0-9]/, { message: "Password must contain at least one number" })
      .trim(),
    confirmPassword: z.string().trim(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  })

const SignInSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }).trim(),
  password: z.string().min(1, { message: "Password is required" }).trim(),
})

export async function signUp(prevState: FormState, formData: FormData): Promise<FormState | never> {
  const validationData = {
    firstName: formData.get("firstName"),
    secondName: formData.get("secondName"),
    email: formData.get("email"),
    password: formData.get("password"),
    confirmPassword: formData.get("confirmPassword"),
  }

  const validatedFields = SignUpSchema.safeParse(validationData)

  if (!validatedFields.success) {
    return {
      message: "Please fix the errors below",
      errors: validatedFields.error.flatten().fieldErrors as FormState["errors"],
    }
  }

  const { firstName, secondName, email, password } = validatedFields.data

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/Register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ firstName, secondName, email, password }),
      cache: "no-store",
    })

    if (!res.ok) {
      const errorData = await res.json()
      console.log("error", errorData)
      const serverErrors: FormState["errors"] = {
        firstName: errorData?.errors?.firstName ?? [],
        secondName: errorData?.errors?.secondName ?? [],
        email: errorData?.errors?.email ?? [],
        password: errorData?.errors?.password ?? [],
        confirmPassword: [],
      }

      return {
        message: errorData?.message || "Registration failed. Please fix the errors.",
        errors: serverErrors,
      }
    }
  } catch (error: any) {
    return {
      message: "An error occurred during signup. Please try again.",
      errors: {
        firstName: [],
        secondName: [],
        email: [],
        password: [],
        confirmPassword: [],
      },
    }
  }

  redirect("/sign-up/success")
}

export async function signIn(prevState: SignInFormState, formData: FormData): Promise<SignInFormState | never> {
  const validationData = {
    email: formData.get("email"),
    password: formData.get("password"),
  }

  const validatedFields = SignInSchema.safeParse(validationData)

  if (!validatedFields.success) {
    return {
      message: "Please fix the errors below",
      errors: validatedFields.error.flatten().fieldErrors as SignInFormState["errors"],
    }
  }

  const { email, password } = validatedFields.data

  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/authenticate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
      cache: "no-store",
    })

    if (!res.ok) {
      const errorData = await res.json()
      return {
        message: errorData?.message || "Invalid credentials",
        errors: {
          email: [],
          password: [],
        },
      }
    }

    const data = await res.json()
    const cookieStore = await cookies()

    cookieStore.set("token", data.authToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    })

    

  } catch (error) {
    console.error("Sign in error:", error)
    return {
      message: "An error occurred during sign in. Please try again.",
      errors: {
        email: [],
        password: [],
      },
    }
  }

  redirect("/user-profile")
}



export async function isAuth () {
  const cookieStore = await cookies()
  const token = cookieStore?.get("token")

  return token?.value
}


export async function isTwoFactorAuthenticated () {
   try {
          const cookieStore = await cookies()
          const token = cookieStore.get("token")?.value
  
          const isAuth = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/TwoFactor/has-2fa`, {
              method: "GET",
              headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${token}`,
              }
          })
  
  
          if (!isAuth.ok) {
              throw new Error("Failed to fetch two factor auth:")
          }
  
          const response = await isAuth.json()
  
          return response
  
      } catch (error) {
          console.error("Error fetching two factor auth:", error)
          return []
      }
   
}



export async function sendTwoFactorCode() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const code = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/TwoFactor/send-2fa-code`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
      },
    });

    if (!code.ok) {
      throw new Error("Failed to send 2FA code");
    }

    const contentType = code.headers.get("content-type");
    let response;

    if (contentType && contentType.includes("application/json")) {
      response = await code.json();
    } else {
      response = await code.text();
    }

    console.log("2FA send response:", response);
    return response;

  } catch (error) {
    console.error("Error fetching send a code:", error);
    return null;
  }
}



export async function verifyCode(code: string) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const verify = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/TwoFactor/verify-2fa`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ code })
    });

    console.log(verify, "verify");
    if (!verify.ok) {
      const errorDetails = await verify.text(); 
      console.error("Verify failed response body:", errorDetails);
      throw new Error("Failed to verify a code");
    }

    const response = await verify.json();
    console.log('response', response);
    return response;

  } catch (error) {
    console.error("Error verifying a code:", error);
    return null;
  }
}



export async function logout () {
  const cookieStore = await cookies()
  cookieStore?.delete("token")
  redirect('/sign-in')
}


export async function authenticateWithBackend() {
  const user = await currentUser()
  console.log(user, "user")

  if (!user || !user.emailAddresses?.[0]) {
    throw new Error("No user info found")
  }

  const email = user.emailAddresses[0].emailAddress
  const firstName = user.firstName || "Unknown"
  const secondName = user.lastName || "User"
  const password = "String123!" 

  try {
    const authRes = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/authenticate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    })

    if (!authRes.ok) {
      const err = await authRes.json().catch(() => ({}))
      console.error("Auth failed:", err)
      throw new Error(`Backend auth failed: ${JSON.stringify(err)}`)
    }

    const data = await authRes.json()

    const cookieStore = await cookies()
    cookieStore.set("token", data.authToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    })

    console.log("Authentication successful, redirecting to user profile.")
  } catch (error) {
    console.error("Backend sign in error:", error)
    throw error
  }

  
  redirect("/user-profile")
}


export async function authenticateWithBackendSignUp() {
  const user = await currentUser()

  if (!user || !user.emailAddresses?.[0]) {
    throw new Error("No user info found")
  }

  const email = user.emailAddresses[0].emailAddress
  const firstName = user.firstName || "Unknown"
  const secondName = user.lastName || "User"
  const password = "String123!"


  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/Register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ firstName, secondName, email, password }),
    })

    if (res.status === 409) {
      console.warn("User already exists, skipping registration and proceeding to authentication.")
    } else if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      console.error("Registration failed:", err)
      throw new Error("User registration failed")
    } else {
      console.log("User registered successfully.")
    }
  } catch (err) {
    if (err instanceof Error && err.message !== "User registration failed") {
      console.error("Network or other registration error:", err)
      throw err
    }
  
    if (err instanceof Error && err.message === "User registration failed") {
      throw err 
    }
  }

  try {
    const authRes = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/authenticate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    })

    if (!authRes.ok) {
      const err = await authRes.json().catch(() => ({}))
      console.error("Auth failed:", err)
      throw new Error("Backend auth failed")
    }

    const data = await authRes.json()

    const cookieStore = await cookies()
    cookieStore.set("token", data.authToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    })

    redirect("/user-profile")
  } catch (error) {
    console.error("Backend sign in error:", error)
    throw error
  }
}
