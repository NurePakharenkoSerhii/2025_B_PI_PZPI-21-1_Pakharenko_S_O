"use server"

import { cookies } from "next/headers"

export type Category = {
    id: number
    categoryName: string
}

export type NewCategory = {
  categoryName: string;
};

export async function getAllCategories(): Promise<Category[]> {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const categories = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Categories`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!categories.ok) {
            throw new Error("Failed to fetch categories:")
        }

        const response: Category[] = await categories.json()

        return response

    } catch (error) {
        console.error("Error fetching categories:", error)
        return []
    }
}




export async function addCategory(data: NewCategory): Promise<boolean> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/admin/AddCategory`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json-patch+json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error("Failed to add category");
    }

    return true;
  } catch (error) {
    console.error("Error adding category:", error);
    return false;
  }
}


