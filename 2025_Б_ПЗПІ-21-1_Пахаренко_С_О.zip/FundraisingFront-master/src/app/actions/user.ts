"use server"

import { cookies } from "next/headers"

export async function getUserProfile() {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const user = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/Profile`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!user.ok) {
            throw new Error("Failed to fetch user:")
        }

        const response = await user.json()

        return response

    } catch (error) {
        console.error("Error fetching user:", error)
        return []
    }
}


export async function editUserProfile(formData: FormData) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/User/EditUserProfile`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      }
    );

    if (!response.ok) {
      throw new Error("Failed to update user profile");
    }

    return await response.json();
  } catch (error) {
    console.error("Error updating user profile:", error);
    return [];
  }
}

export async function getUsersWithSort(sortDesc: boolean = false) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/admin/userFilter?SortDesc=${sortDesc}`,
      {
        method: "GET",
        headers: {
          accept: "*/*",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to fetch user data");
    }

    return await response.json();
  } catch (error) {
    console.error("Error fetching users with sort:", error);
    return [];
  }
}



export type UserSettings = {
  notifyNewFundraising: boolean
  notifyNewInitiative: boolean
  notifyGoalReached: boolean
  frequencyInHours: number
}

export async function getUserSettings(): Promise<UserSettings | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/GetUserSettings`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to fetch user settings")
    }

    const data: UserSettings = await response.json()
    return data
  } catch (error) {
    console.error("Error fetching user settings:", error)
    return null
  }
}



export type UpdateUserSettingsInput = {
  notifyNewFundraising: boolean
  notifyNewInitiative: boolean
  notifyGoalReached: boolean
  frequencyInHours: number
}

export async function updateUserSettings(input: UpdateUserSettingsInput) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/User/UpdateUserSettings`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json-patch+json",
        "Accept": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify(input),
    })

    if (!response.ok) {
      throw new Error("Failed to update user settings")
    }

    return true
  } catch (error) {
    console.error("Error updating user settings:", error)
    return false
  }
}