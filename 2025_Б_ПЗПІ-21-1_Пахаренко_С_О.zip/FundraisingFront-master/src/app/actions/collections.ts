"use server"

import { cookies } from "next/headers"

 type FundraisingForm = {
        title: string
        goalAmount: number
        deadline: Date | undefined | string
}

export async function createCollection(collection:FundraisingForm) {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
            body:JSON.stringify(collection)
        })


        if (!initiatives.ok) {
            throw new Error("Failed to create collection:")
        }

        const response = await initiatives.json()

        return response

    } catch (error) {
        console.error("Error create collection:", error)
        return []
    }
}


export async function getAllCollectionByInitiativeId(id:number) {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings/byInitiative/${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!initiatives.ok) {
            throw new Error("Failed to fetch collections:")
        }

        const response = await initiatives.json()

        return response

    } catch (error) {
        console.error("Error fetching collections:", error)
        return []
    }
}

export async function getCollectionStatistics(id:number) {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const initiatives = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings/${id}/statistics`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!initiatives.ok) {
            throw new Error("Failed to fetch collections:")
        }

        const response = await initiatives.json()

        return response

    } catch (error) {
        console.error("Error fetching collections:", error)
        return []
    }
}


export async function getAllFundraisingsAdmin() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/admin/GetAllFundraisings`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to fetch all fundraisings (admin)");
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching admin fundraisings:", error);
    return [];
  }
}

export async function deleteCollection(id: number) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings/FundraisingDelete?id=${id}`,
      {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error(`Failed to delete collection with id ${id}`);
    }

    return { success: true };
  } catch (error) {
    console.error("Error deleting collection:", error);
    return { success: false, error: String(error) };
  }
}

export async function blockFundraising(id: number, isBlocked: boolean) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings/admin/block?id=${id}&isBlocked=${isBlocked}`,
      {
        method: "PATCH",
        headers: {
          Accept: "*/*",
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (!res.ok) {
      throw new Error("Failed to block/unblock fundraising")
    }

    if (res.status !== 204) {
      const data = await res.json()
      return { success: true, data }
    }

    return { success: true }

  } catch (error) {
    console.error("Error blocking/unblocking fundraising:", error)
    return { success: false, error: (error as Error).message }
  }
}


export async function getFundraisingNotes() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get("token")?.value

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Fundraisings/getNotes`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${token}`,
      },
    })

    if (!res.ok) {
      throw new Error("Failed to fetch fundraising notes")
    }

    const text = await res.json()
    return text

  } catch (error) {
    console.error("Error fetching fundraising notes:", error)
    return null
  }
}