"use server"

import { cookies } from "next/headers"




export async function getAllTopDonors(id:number) {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const topDon = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Donate/top-donors?fundraisingId=${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!topDon.ok) {
            throw new Error("Failed to fetch top donors:")
        }

        const response = await topDon.json()

        return response

    } catch (error) {
        console.error("Error fetching top donors:", error)
        return []
    }
}

export async function getMyDonationHistory() {
    try {
        const cookieStore = await cookies()
        const token = cookieStore.get("token")?.value

        const topDon = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Donate/MyDonates`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            }
        })


        if (!topDon.ok) {
            throw new Error("Failed to fetch top donors:")
        }

        const response = await topDon.json()

        return response

    } catch (error) {
        console.error("Error fetching top donors:", error)
        return []
    }
}