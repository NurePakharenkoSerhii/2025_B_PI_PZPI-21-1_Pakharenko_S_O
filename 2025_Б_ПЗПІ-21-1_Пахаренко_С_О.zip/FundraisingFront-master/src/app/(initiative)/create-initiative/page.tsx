"use client"

import type React from "react"
import { startTransition, useEffect, useState } from "react"
import {  ChevronLeft, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { Category, getAllCategories } from "@/app/actions/categories"
import { createInitiative } from "@/app/actions/initiatives"
import { isTwoFactorAuthenticated } from "@/app/actions/auth"
import { toast } from "sonner"
import { Loader } from "@/components/loader"




export default function CreateInitiativePage() {
  const [categories, setCategories] = useState<Category[]>()
  const [isTwoFactor, setIsTwoFactor] = useState<boolean>(false)
  

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    image: null as File | null,
  })
  const [imagePreview, setImagePreview] = useState<string | null>(null)


    useEffect(() => {
    startTransition(async () => {
      const response = await getAllCategories()
      const hash2FA = await isTwoFactorAuthenticated();
      setIsTwoFactor(hash2FA);
      setCategories(response)
    })
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, category: value }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setFormData((prev) => ({ ...prev, image: file }))

      const reader = new FileReader()
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }



const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  const { title, description, category, image } = formData;

  if (!isTwoFactor) {
    toast.error("Функція недоступна. Будь ласка, пройдіть двофакторну автентифікацію.");
    return;
  }

  const matchedCategory = categories?.find(
    (cat) => cat.categoryName === category
  );

  if (!matchedCategory) {
    console.error("Category not found");
    return;
  }

  const form = new FormData();
  form.append("Title", title);
  form.append("Description", description);
  form.append("CategoryId", String(matchedCategory.id));

  if (image) {
    form.append("ImageFile", image);
  }

  try {
    await createInitiative(form);

    setFormData({
      title: "",
      description: "",
      category: "",
      image: null,
    });

    setImagePreview(null);
    toast.success("Ініціатива успішно створена!");
  } catch (error) {
    console.error("Failed to create initiative:", error);
    toast.error("Не вдалося створити ініціативу. Спробуйте пізніше.");
  }
};


  return (
    <div className="container mx-auto p-4 max-w-2xl">
      <div className="mb-6">
        <Button variant="ghost" className="flex items-center gap-2 pl-0 hover:bg-transparent" asChild>
          <Link href="/user-profile" className="text-gray-600 hover:text-gray-900">
            <ChevronLeft size={20} />
            <span>Назад до профілю</span>
          </Link>
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h1 className="text-2xl font-semibold mb-6">Створити Ініціативу</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Назва ініціативи</Label>
            <Input
              id="title"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              placeholder="Введіть назву ініціативи"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Опис ініціативи</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Введіть детальний опис ініціативи"
              rows={5}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Категорії</Label>
            <Select value={formData.category} onValueChange={handleSelectChange} required>
              <SelectTrigger>
                <SelectValue placeholder="Оберіть категорію" />
              </SelectTrigger>
              <SelectContent>
                {categories?.map((category) => (
                  <SelectItem key={category.id} value={category.categoryName}>
                    {category.categoryName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="image">Завантажити фото</Label>
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById("image")?.click()}
                  className="flex items-center gap-2"
                >
                  <Upload size={16} />
                  Обрати файл
                </Button>
                <Input
                  id="image"
                  name="image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
                <span className="text-sm text-gray-500">{formData.image ? formData.image.name : "Файл не обрано"}</span>
              </div>

              {imagePreview && (
                <div className="mt-2">
                  <div className="relative w-full h-48 bg-gray-100 rounded-md overflow-hidden">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          <Button type="submit" className="w-full mt-8">
            Створити
          </Button>
        </form>
      </div>
    </div>
  )
}
