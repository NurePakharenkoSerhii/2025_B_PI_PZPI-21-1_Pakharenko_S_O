"use client";
import { AdminInitiativeCard } from "./admin-initiative-card";


export type Initiative = {
  id: number;
  title: string;
  description: string;
  imageBase64: string; 
};

export const AdminInitiativeCardList = ({ cards }: { cards: Initiative[] }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((initiative) => (
        <AdminInitiativeCard
          key={initiative.id}
          id={initiative.id}
          image={initiative.imageBase64}
          title={initiative.title}
          description={initiative.description}
          useEllipsisMenu={true}
          onEdit={() => console.log("Edit", initiative.id)}
          onStats={() => console.log("Stats", initiative.id)}
          onDelete={() => console.log("Delete", initiative.id)}
        />
      ))}
    </div>
  );
};
