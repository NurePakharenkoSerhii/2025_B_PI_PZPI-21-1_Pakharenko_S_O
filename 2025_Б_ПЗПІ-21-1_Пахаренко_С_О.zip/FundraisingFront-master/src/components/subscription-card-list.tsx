"use client";

import { Card } from "./card-base";


type CardData = {
  id: number
  image: string
  title: string
  description: string
}

type Props = {
  cards: CardData[]
  onRemove: (id: number) => void
}

export const SubscriptionCardList = ({ cards, onRemove }: Props) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((card) => (
        <Card
          id={card.id}
          key={card.id}
          image={card.image}
          title={card.title}
          description={card.description}
          onRemove={() => onRemove(card.id)}
        />
      ))}
    </div>
  )
}
