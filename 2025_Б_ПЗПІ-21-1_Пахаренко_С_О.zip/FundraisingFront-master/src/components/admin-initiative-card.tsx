"use client";
import { useState } from "react";
import { useRouter } from "next/navigation"


type CardProps = {
  id: number
  image: string
  title: string
  description: string
  onRemove?: () => void
  useEllipsisMenu?: boolean
  onEdit?: () => void
  onStats?: () => void
  onDelete?: () => void
}

export const AdminInitiativeCard = ({
  id,
  image,
  title,
  description,
  onRemove,
  useEllipsisMenu = false,
  onEdit,
  onStats,
  onDelete,
}: CardProps) => {
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const router = useRouter()

  const handleRemoveClick = () => {
    setShowConfirmDialog(true)
  }

  const handleConfirm = () => {
    if (onRemove) {
      onRemove()
    }
    setShowConfirmDialog(false)
  }

   const handleCardClick = () => {
    router.push(`/admin-initiative/${id}`)
  }


  const handleDelete = () => {
    setShowConfirmDialog(true)
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden w-full max-w-sm relative group cursor-pointer">
      <div className="relative w-full h-40"
        onClick={handleCardClick}>
          <img src={`data:image/jpeg;base64,${image}`} alt="base" className="object-cover w-full h-full"/>
      </div>
      <div className="p-4 space-y-2">
        <h2 className="text-lg font-semibold text-gray-800">{title}</h2>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </div>
  )
}

type Initiative = {
  id: number;
  imageBase64: string;
  title: string;
  description: string;
};

type CardListProps = {
  showRemove?: boolean;
  initiatives?: Initiative[];
};


export const CardList = ({ showRemove = false, initiatives = [] }: CardListProps) => {
  const [internalCards, setInternalCards] = useState(initiatives);
 const cards = initiatives || internalCards;
  const router = useRouter();

  const handleRemove = (id: number) => {
    setInternalCards(internalCards.filter((card) => card.id !== id));
  };

   const handleEdit = (id: number) => {
    router.push(`/edit-initiative/${id}`);
  };


  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((card) => (
        <AdminInitiativeCard
          key={card.id}
           id={card.id}
          image={card.imageBase64}
          title={card.title}
          description={card.description}
        />
      ))}
    </div>
  );
};


