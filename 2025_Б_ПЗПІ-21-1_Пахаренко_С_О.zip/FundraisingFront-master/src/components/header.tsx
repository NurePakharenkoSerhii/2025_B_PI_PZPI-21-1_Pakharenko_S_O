"use client";
import Link from "next/link"
import { BookOpen, User } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header({ isAuthPage  , token}: { isAuthPage?: boolean, token?: string | null }) {
 

  const isAuthenticated = !!token;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link className="flex gap-2 items-center" href="/">
            <BookOpen className="h-6 w-6" />
            <span className="text-lg font-semibold">Initiatives</span>
          </Link>
        </div>
        {!isAuthPage ? (
          <nav className="flex items-center gap-4 ml-auto">
            {isAuthenticated ? (
              <Button variant="ghost" size="sm" asChild>
                <Link href="/user-profile" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Профіль
                </Link>
              </Button>
            ) : (
              <>
                <Button variant="ghost" asChild>
                  <Link href="/sign-in">Увійдіть</Link>
                </Button>
                <Button asChild>
                  <Link href="/sign-up">Зареєструватися</Link>
                </Button>
              </>
            )}
          </nav>
        ) : null}

      </div>
    </header>
  )
}
