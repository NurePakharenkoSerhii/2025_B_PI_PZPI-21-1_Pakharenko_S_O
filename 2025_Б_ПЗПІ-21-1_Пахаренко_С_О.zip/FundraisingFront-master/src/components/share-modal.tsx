"use client"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Check, Copy } from "lucide-react"

interface ShareModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  url: string
}

export function ShareModal({ open, onOpenChange, url }: ShareModalProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy text: ", err)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Швидке поширення</DialogTitle>
        </DialogHeader>
        <div className="flex items-center space-x-2 mt-4">
          <div className="grid flex-1 gap-2">
            <Input readOnly value={url} placeholder="Ваше унікальне посилання" className="h-10" />
          </div>
          <Button
            type="button"
            size="sm"
            className="px-3 h-10"
            onClick={handleCopy}
            variant={copied ? "outline" : "default"}
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 mr-2" />
                Скопійовано
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-2" />
                Копіювати
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
