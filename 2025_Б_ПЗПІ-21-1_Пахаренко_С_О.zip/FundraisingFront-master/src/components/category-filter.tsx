"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface Category {
  id: number
  categoryName: string
}

interface CategoryFilterProps {
  categories: Category[]
  onApplyFilter: (selectedCategories: string[]) => void
  initialSelected?: string[]
}

export function CategoryFilter({ categories, onApplyFilter, initialSelected = [] }: CategoryFilterProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>(initialSelected)

  const handleCategoryChange = (categoryName: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, categoryName])
    } else {
      setSelectedCategories(selectedCategories.filter((name) => name !== categoryName))
    }
  }

  const handleApplyFilter = () => {
    onApplyFilter(selectedCategories)
  }

  return (
    <div className="space-y-4 border rounded-lg p-4">
      <h3 className="font-medium text-lg">Фільтрувати за категоріями</h3>
      <div className="space-y-2">
        {categories.map((category) => (
          <div key={category.id} className="flex items-center space-x-2">
            <Checkbox
              id={`category-${category.id}`}
              checked={selectedCategories.includes(category.categoryName)}
              onCheckedChange={(checked) => handleCategoryChange(category.categoryName, checked === true)}
            />
            <Label htmlFor={`category-${category.id}`}>{category.categoryName}</Label>
          </div>
        ))}
      </div>
      <Button onClick={handleApplyFilter} className="w-full">
        Підтвердити
      </Button>
    </div>
  )
}
