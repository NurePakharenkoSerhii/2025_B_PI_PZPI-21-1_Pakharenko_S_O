
export  function Loader() {
  return (
    <section className="flex items-center justify-center h-full w-full">
      <div className="h-5 w-5 mr-2 rounded-full bg-blue-200 animate-pulse-delay-1"></div>
      <div className="h-5 w-5 mr-2 rounded-full bg-blue-200 animate-pulse-delay-2"></div>
      <div className="h-5 w-5 mr-2 rounded-full bg-blue-200 animate-pulse-delay-3"></div>
      <div className="h-5 w-5 mr-2 rounded-full bg-blue-200 animate-pulse-delay-4"></div>
      <div className="h-5 w-5 rounded-full bg-blue-200 animate-pulse-delay-5"></div>
    </section>
  );
}