import { type NextRequest, NextResponse } from "next/server"
import { clerkMiddleware } from '@clerk/nextjs/server'

export default clerkMiddleware()

/* export function middleware(request: NextRequest) {
  const token = request.cookies.get("token")
  const { pathname } = request.nextUrl

  const protectedRoutes = ["/user-profile"]

  const isProtectedRoute = protectedRoutes.some((route) => pathname.startsWith(route))

  if (pathname.startsWith("/_next") || pathname.startsWith("/images")) {
    return NextResponse.next()
  }

  if (isProtectedRoute && !token) {
    const signInUrl = new URL("/sign-in", request.url)
    signInUrl.searchParams.set("redirect", pathname)
    return NextResponse.redirect(signInUrl)
  }

  if (token && (pathname === "/sign-in" || pathname === "/sign-up")) {
    return NextResponse.redirect(new URL("/user-profile", request.url))
  }

  return NextResponse.next()
} */

export const config = {
  matcher: [
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    '/(api|trpc)(.*)',
  ],
}
