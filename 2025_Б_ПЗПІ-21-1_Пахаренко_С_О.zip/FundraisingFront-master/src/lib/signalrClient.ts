"use client";

import * as signalR from "@microsoft/signalr";
import { toast } from "sonner";

let connection: signalR.HubConnection | null = null;

export async function getSignalRConnection(token: string) {
    if (connection && connection.state === signalR.HubConnectionState.Connected) {
        return connection;
    }

    if (!connection) {
        connection = new signalR.HubConnectionBuilder()
            .withUrl(`${process.env.NEXT_PUBLIC_API_BASE}/hubs/fundraising`, {
                accessTokenFactory: () => token,
                skipNegotiation: true,
                transport: signalR.HttpTransportType.WebSockets,
            })
            .withAutomaticReconnect()
            .build();

        connection.onclose(error => {
            console.error("SignalR connection closed:", error);
        });

        connection.on("FundraisingGoalReached", (data) => {
            console.log("🎯 Ціль збору досягнута:", data);
            toast.success(`Ціль досягнута: ${data.title} — зібрано $${data.goal}`);
        });

        connection.on("NewFundraisingCreated", (data) => {
            console.log("🚀 Створено новий збір коштів:", data);
            toast(`Створено новий збір: ${data.title} — Мета: $${data.goal} до ${data.deadline}`);
        });

        await connection.start();
        console.log("✅ SignalR connection established");
    }

    return connection;
}
