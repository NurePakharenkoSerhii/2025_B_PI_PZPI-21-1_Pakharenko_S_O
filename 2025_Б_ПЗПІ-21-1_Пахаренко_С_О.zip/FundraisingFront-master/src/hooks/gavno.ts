"use client";
import { isAuth } from "@/app/actions/auth";
import { getSignalRConnection } from "@/lib/signalrClient";

type StripeSession = {
    fundraisingId:number;
    amount:number;
    successUrl: string;
    cancelUrl: string;
}




export async function subscribeToInitiative(initiativeId: number) {
  try {
    const token = await isAuth();
    if (!token) throw new Error("No token");

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/api/Subscribe`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json-patch+json",
        "Authorization": `Bearer ${token}`,
        "Accept": "*/*",
      },
      body: JSON.stringify({ initiativeId }),
    });

    if (!response.ok) throw new Error("Failed to subscribe");

    const connection = await getSignalRConnection(token);
    await connection.invoke("SubscribeToInitiative", initiativeId);

    return await response.json();
  } catch (err) {
    console.error("Error in subscribeToInitiative", err);
    return null;
  }
}


export async function unsubscribeFromInitiative(initiativeId: number | null) {
  try {
    if (!initiativeId) throw new Error("Initiative ID is required");

    const token = await isAuth();
    if (!token) throw new Error("Authentication token not found");

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/Subscribe/UnsubscribeFromInitiative?id=${initiativeId}`,
      {
        method: "DELETE",
        headers: {
          "Accept": "*/*",
          "Authorization": `Bearer ${token}`,
        },
      }
    );

    console.log(response, "🗑️ Unsubscribe response");

    if (!response.ok) {
      throw new Error("Failed to unsubscribe from initiative");
    }

    const connection = await getSignalRConnection(token);
    await connection.invoke("UnsubscribeFromInitiative", initiativeId);
    console.log(`👋 Unsubscribed from initiative ${initiativeId} via SignalR`);

    if (response.status === 204) {
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error("❌ Error unsubscribing from initiative:", error);
    return null;
  }
}



export async function createCheckoutSession(stripeSession: StripeSession) {
  try {
    const token = await isAuth();

    if (!token) throw new Error("Authentication token not found");

    const response = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE}/api/Stripe/create-checkout-session`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(stripeSession),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to create Stripe session");
    }

    //await getSignalRConnection(token);

    const result = await response.json();
    return result;
  } catch (error) {
    console.error("❌ Error creating Stripe session:", error);
    return null;
  }
}
