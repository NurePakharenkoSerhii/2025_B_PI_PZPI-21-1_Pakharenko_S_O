import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: ['local-origin.dev', '*.local-origin.dev'],
  experimental:{
    serverActions:{
      bodySizeLimit:"2mb"
    }
  }
};

export default nextConfig;
